Thank you for downloading the Video Flicker Investgation Tool (VIFIT)!

Build: 04/27/2011
By Alexander Harding

For more information on this tool, for updates, and for the source, please go to http://code.google.com/p/vifitool/.